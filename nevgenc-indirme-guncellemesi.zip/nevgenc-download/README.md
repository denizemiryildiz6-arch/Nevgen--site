# NevGenç indirme bağlantısı güncellemesi

Bu paket, https://nevgenc-site.vercel.app adresinin yayınlanan statik dosyalarından hazırlanmıştır. Orijinal React/Next.js kaynak projesi değildir. Yayınlanan JavaScript, görseller ve animasyonlar korunmuştur.

## Değişiklikler
- Üst menü ve ana bölümdeki “Çok yakında” metni “Uygulamayı indir” oldu; mevcut #download geçişi korundu.
- Google Play ve App Store alanları gerçek mağaza bağlantılarıyla çalışır ve yeni sekmede açılır.
- Yayın bekleme metinleri Türkçe ve İngilizce için güncellendi.
- Düzen, renkler, görseller, dil değiştirme kodu, geçişler ve animasyon kodu korunmuştur. Mağaza alanlarının CSS seçicisi link öğesine uyarlanmış, imleç tıklanabilir olarak güncellenmiştir.
- Gizlilik Politikası sayfası pakete dahil edilmiştir.

## Mevcut Vercel projesine yükleme
1. Paketi aç. Önce mevcut projenin yedeğini al.
2. Vercel'de aynı projenin ayarlarında Framework Preset'i Other seç.
3. Root Directory bu paketin kökü, Output Directory `dist` olmalı. Build Command boş bırakılabilir; gerekirse `npm run build` kullan.
4. Dosyaları mevcut projenin bağlı deposuna koyup dağıtımı başlat veya bilgisayarında bu klasörden `npx vercel --prod` çalıştırıp mevcut `nevgenc-site` projesini seç.

Canlı Vercel sitesi bu paket hazırlanırken değiştirilmedi. Dosyalar yerel bir HTTP sunucusuyla açılmalıdır; index.html dosyasına doğrudan çift tıklamak /assets ve /_next yollarını çalıştırmaz.

## Doğrulama
Mağaza linkleri, HTML/React eşleşmesi, JavaScript sözdizimi, yerel varlık yolları ve orijinal animasyon CSS/IntersectionObserver kodunun korunması kontrol edildi. Görsel tarayıcı testi yapılmadı.
